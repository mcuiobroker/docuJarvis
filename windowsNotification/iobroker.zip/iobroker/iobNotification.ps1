Param (
    [string]$JsonParameter
)
#Write-Host $JsonParameter

# Bypass der Execution Policy
Set-ExecutionPolicy Bypass -Scope Process -Force

# Importieren des BurntToast-Moduls
Import-Module BurntToast


function Convert-SpecialCharactersToUnicode($inputString) {
    # Definieren Sie eine Hashtabelle, die die Zuordnung von Sonderzeichen zu Unicode-Sequenzen enth�lt
    $specialCharacters = @{
        "�" = $([char]0x00B0)
        "!" = $([char]0x0021)
        # F�gen Sie hier weitere Sonderzeichen und ihre Unicode-Sequenzen hinzu
    }

    # Durchlaufen Sie die Hashtabelle und ersetzen Sie alle �bereinstimmenden Sonderzeichen im Eingabestring
    foreach ($entry in $specialCharacters.GetEnumerator()) {
        $inputString = $inputString -replace [regex]::Escape($entry.Key), $entry.Value
    }

    # Geben Sie den modifizierten String zur�ck
    return $inputString
}


function Send-ToIO {
    param (
        [string]$ioBrokerUrl,
        [string]$stateDP,
        [string]$valueToSend
    )

    $simpleApiUrl = "$ioBrokerUrl/set/$($stateDP)?value=$valueToSend"
    Write-Host 'SimpleApi: ' $simpleApiUrl
    try {
        $response = Invoke-RestMethod -Uri $simpleApiUrl -Method Get
        Write-Host "Erfolgreich gesendet: $($response)"
    } catch {
        Write-Host "Fehler beim Senden der Anfrage: $($_.Exception.Message)"
    }
}

$Activated = {
    Write-Host 'aktiviert'
    if($Event.SourceArgs[1].Arguments -eq 'dismiss'){
        Write-Host 'Activ dismiss'
    }else{
        Write-Host 'Arguments: ' $Event.SourceArgs[1].Arguments
        Write-Host 'UserInput: ' $Event.SourceArgs[1].UserInput
        $Global:ToastEvent = $Event
        $ioBrokerUrl = "http://$($iobIpAdress):8087"  # Ersetzen Sie dies durch Ihre ioBroker-URL
        
        if($selectArr -ne '[]'){
            $evtVar =  $Event.SourceArgs[1].UserInput -split ','
            $stateDP = $evtVar[1].replace(']','').Trim()
            $splitArgu =$Event.SourceArgs[1].Arguments -split ','
            $splitVal = $splitArgu[2] -split (':')
            $valueToSend = $splitVal[1].Trim()
            #$valueToSend = $($Event.SourceArgs[1].Arguments)    
        }else{
            # evtl alle Buttons durchsuchen nach val = Arguments
            if($Event.SourceArgs[1].Arguments){
                $objArg =@{}
                $splitArgu =$Event.SourceArgs[1].Arguments -split ','
                $splitDP = $splitArgu[1] -split (':')
                $stateDP = $splitDP[1].replace('"','').replace('"','').Trim()
                Write-Host $splitDP
                $splitVal = $splitArgu[2] -split (':')
                $valueToSend = $splitVal[1].Trim()
            }
        }
        Write-Host 'StateDP: ' $stateDP
        Write-Host 'ValueToSend: ' $valueToSend
        Send-ToIO -ioBrokerUrl $ioBrokerUrl -stateDP $stateDP -valueToSend $valueToSend
    }
}
$Dismissed ={
    Write-Host 'Dismissed'
    if($Event.SourceArgs[1].Reason -eq 'Timedout'){
        Write-Host 'dismissed Timeout' $Event.SourceArgs
        $Global:ToastEvent = $Event
    }elseif($Event.SourceArgs[1].Reason -eq 'UserCanceled'){
        Write-Host 'User dismissed'
        $Global:ToastEvent = $Event
    }
}

function close-Tab {
    param($url)
    Get-Process | Format-Table -AutoSize
    $oWindows = (New-Object -ComObject Shell.Application).Windows

    foreach ($oWindow in $oWindows.Invoke()) {
        Write-Host "Prozess: $($oWindow.Fullname), URL: $($oWindow.LocationURL)"
        
        if ($oWindow.Fullname -match "msedge.exe" -and $oWindow.LocationURL -match $url) {
            Write-Host "Schlie�e Tab: $($oWindow.LocationURL)"
            $oWindow.Quit()
        }
    }
}

$receivedData = ConvertFrom-Json $JsonParameter

Write-Host $receivedData
# Verarbeiten der empfangenen Daten
$iobIpAdress = $receivedData.iobIpAdress
Write-Host 'iobIPAdress: ' $iobIpAdress
$sound = $receivedData.sound
$heroImage = $receivedData.heroImage
$title =  $receivedData.title
#Write-Host $title
$message = $receivedData.message
$timeout = $receivedData.time
$iconUrl = $receivedData.iconUrl #"C:\\DATEN\\iobroker\\"+
#Write-Host $iconUrl
$timeToSetValues = $receivedData.timeToSetValues
$appID = $receivedData.appID

if($appID){
    New-BTAppId -AppId $appID #sicherstellen, dass App regisitriert wird
}
$header = $receivedData.header
if($header){
    $headerBT = New-BTHeader -Title $header
}

$id = $receivedData.id
$logging = $receivedData.logging
if($logging){
    #$received = ConvertTo-Json $receivedData
    #Write-Host "Empfangene Daten: `n"  $received
    Write-Host "`n PowerShell-Version: " $PSVersionTable.PSVersion
}else{
    Write-Host "`n Logging ist ausgeschaltet" 
}

$progressArr = ConvertTo-Json $receivedData.progressArr
$colArr      = ConvertTo-Json $receivedData.colArr
#Write-Host $receivedData.buttonArr
$buttonArr   = ConvertTo-Json $receivedData.buttonArr
$selectArr   = ConvertTo-Json $receivedData.selectArr

# Registry �ndern
# funktioniert man muss aber abmelden und neu anmelden

#$RegistryPath = "HKCU:\Control Panel\Accessibility"
#$Name = "MessageDuration"
#$Value = 3  # Der neue Wert, den Sie setzen m�chten (in Millisekunden)

# Setzen Sie den Wert des Registry-Eintrags
#Set-ItemProperty -Path $RegistryPath -Name $Name -Value $Value
#Write-Host "neuen Wert f�r Registry gesetzt"




# Write-Host  $colArr
# Wandeln Sie die Zeichenfolgen in g�ltiges JSON um
$labels = @()
$values = @()
if($receivedData.colArr -ne ''){
    $validJsonStrings = $colArr -replace "'", '"'
    # Write-Host $validJsonStrings
    # Jetzt k�nnen Sie die JSON-Daten verarbeiten
    $jsonObjects = ConvertFrom-Json $validJsonStrings
    # Write-Host $jsonObjects


    #$label = New-BTText -Text "--------------------------------" -Style Base
    #$value = New-BTText -Text "-------------------" -Style Base
    #$labels += $label
    #$values += $value

    foreach ($obj in $jsonObjects) {
        $label = New-BTText -Text "$($obj.name)" -Style Base #: $($obj.val)
        $value = New-BTText -Text "$($obj.val) $($obj.unit)" -Style BaseSubtle # $Color #-Style Base
        $labels += $label
        $values += $value
    }

    # Write-Host $labels
    $Column1 = New-BTColumn -Children $labels -Weight 20
    $Column2 = New-BTColumn -Children $values -Weight 10
}else{
    $Column1 = $null
    $Column2 = $null
}
#Write-Host $buttonArr
$onlyUseSubmit = $false
$Buttons = @()
if($receivedData.buttonArr -ne ''){
    #Write-Host $buttonArr
    $buttonArrJson =  ConvertFrom-Json $buttonArr
    #Write-Host $buttonArrJson
    foreach ($obj in $buttonArrJson) {
        #Write-Host $($obj.dp)
        if($obj.dp){
            $onlyUseSubmit = $true
            
            $modifiedString = Convert-SpecialCharactersToUnicode $obj.title
            Write-Host $modifiedString
            $argu = ConvertTo-Json $obj
            $Button = New-BTButton -Id $($obj.title) -Content $($modifiedString)  -Arguments $($argu) -ActivationType Background
        }else{
            if($obj.url){
                $Button = New-BTButton -Id $($obj.title) -Content $($obj.title)    -Arguments $($obj.url)   -ActivationType Protocol 
            }else{
                # DP mit val angegeben
                $Button = New-BTButton -Id $($obj.title) -Content $($obj.title)  -Arguments $($obj.title) -ActivationType Background
            }
        }
        $Buttons += $Button
        #Write-Host $Buttons
    }
    Write-Host 'Nur mit Submit �ffnen: ' $($onlyUseSubmit)
}else{
    $Buttons = $null
}
Write-Host 'SelectArr'  $receivedData.selectArr #$selectArr -ne '[]' -and $selectArr
$SelectItems = @()
if($receivedData.selectArr -ne ''){
    $onlyUseSubmit =$true
    Write-Host 'SelectArr only true gesetzt'
    $defaultItemId = $null
    $selectArrJson =  ConvertFrom-Json $selectArr
    Write-Host $selectArrJson
    foreach ($obj in $selectArrJson){
        $selectItem =New-BTSelectionBoxItem -Id $($obj.id) -Content $($obj.content)
        if($obj.default){
            $defaultItemId = $($obj.id)
        }
        $SelectItems += $selectItem
    }
    $SelectionBox = New-BTInput -Id 'Auswahl' -DefaultSelectionBoxItemId $($defaultItemId) -Items $SelectItems
}else{
    $SelectionBox = $null
}

# Progress Arr bearbeiten
Write-Host 'ProgressArr' $receivedData.progressArr # $progressArr
$progressAll = @()
if($receivedData.progressArr -ne ''){
    $progressArrJson = ConvertFrom-Json $progressArr
    #Write-Host $progressArrJson

    foreach ($obj in $progressArrJson) {
        #Write-Host $obj.valueDisplay
        #$valueDis = "'" +$obj.valueDisplay +"'"
        $progress = New-BTProgressBar -Status $($obj.status) -Value $($obj.value) -ValueDisplay $($obj.valueDisplay)
        $progressAll += $progress
    }
}else{
    $progressAll = $null
}
$soundindex = $sound.IndexOf("mp3") -or $sound.IndexOf("wav")

$jsonString = '{
    "Titel": "Benachrichtigungstitel",
    "Text": "Dies ist eine Beispielbenachrichtigung von BurntToast."
}'

# Konvertieren des JSON-Strings in ein PowerShell-Objekt
$NotiJson = $jsonString | ConvertFrom-Json
$Picture = "C:\DATEN\iobroker\icon.png"
#Button
# http://192.168.178.150:8093/v1/state/0_userdata.0.DP.htmlDP?value=1
#$Button1 = New-BTButton -Id 'OK' -Content 'OK' -Arguments 'http://192.168.178.150:8093/v1/state/0_userdata.0.DP.htmlDP?value=10' -ActivationType Protocol  #-Arguments "$Wert = 5" -ActivationType Protocol 

#$Button2 = New-BTButton -Id 'Abbrechen' -Content 'Abbrechen' -Arguments 'http://192.168.178.150:8093/v1/state/0_userdata.0.DP.htmlDP?value=22' -ActivationType Protocol #-ActivationType 'Foreground' #http://192.168.178.150:8087/set/0_userdata.0.DP.htmlDP?value=2
#$Button = $Button1,$Button2
#Write-Host $Wert
#$Button = New-BTAction -SnoozeAndDismiss

#$Button = New-BTButton -Id "button" -Content $urlContent -Arguments $urlToSend -ActivationType Protocol #-ImageUri $Picture ; Protocol = "confirm-action" #'https://google.com'
# gibt es nicht f�r normale Noti $ContextMenuItem = New-BTContextMenuItem -Content 'Bing' -Arguments 'https://bing.com'

#$Progress = New-BTProgressBar -Status $progressStatus -Value $progressValue -ValueDisplay '4/20 files complete' #wird der Text und nicht % angezeigt
#$ChildProgress = New-BTProgressBar -Status $progressStatus -Value $progressValue -ValueDisplay '20/20 files complete' #wird der Text und nicht % angezeigt

# -Buttons $Button -ContextMenuItems $ContextMenuItem
# New-BurntToastNotification -Text 'File copy running' -ProgressBar $Progress -AppLogo "C:\DATEN\iobroker\icon.png" -Sound Reminder -Button (New-BTButton -Content 'Google' -Arguments 'https://google.com') -InformationAction Continue
# Laden der MP3-Datei
#$wmp.URL = 'C:\DATEN\iobroker\notification.mp3'

# Abspielen der MP3-Datei
#New-BurntToastNotification -Text 'Now Playing' -Column $Column1, $Column2 -WhatIf


# AppID vorhanden?
$notifyOpt = @{
    #$Text1 = New-BTText -Content $($title)
    #$Text2 = New-BTText -Content $($message)
    Text = $title, $message
}
if($id){
    $notifyOpt['UniqueIdentifier'] = $id
}
if ($iconUrl) {
    $notifyOpt['AppLogo'] = $iconUrl
}
if($headerBT){
    $notifyOpt['Header'] = $headerBT
}
if($appID){
    $notifyOpt['AppId'] = $appID
}
if($Column1 -and $Column2){
    $notifyOpt['Column'] = $Column1, $Column2
}
if($Buttons){
    $notifyOpt['Button'] = $Buttons
}
if($progressAll){
    $notifyOpt['ProgressBar'] = $progressAll
}
if($heroImage){
    $notifyOpt['HeroImage'] = $heroImage
}
if($Buttons){
    $notifyOpt['ActivatedAction']= $Activated
    $notifyOpt['DismissedAction']= $Dismissed
}

Write-Host $notifyOpt

if($appID){
    if($soundindex -ge 0){
        Write-Host "MP3 gefunden"
        #Write-Host $id $sound $headerBT
        if($onlyUseSubmit){
            Write-Host 'Submit Variante wird genutzt'
            
            $Text1 = New-BTText -Content $($title)
            $Text2 = New-BTText -Content $($message)
            $action = New-BTAction -Buttons $Buttons -inputs $SelectionBox #$Button, $Button2 # -inputs $SelectionBox #
            # iconUrl und heroImage sind bei Werte setzen nicht m�glich
            #$Binding = New-BTBinding @BindingOpt # -Children $Text1, $Text2 -Column $Column1, $Column2 #HeroImage funktioniert hier nicht
            if ($Column1 -and $Column2) {
                $Binding = New-BTBinding -Children $Text1, $Text2 -Column $Column1, $Column2
            }
            else {
                $Binding = New-BTBinding -Children $Text1, $Text2
            }
            $Visual = New-BTVisual -BindingGeneric $Binding 
            $Content = New-BTContent -Visual $Visual -Actions $action -Launch 'BodyClick'  # -Duration Long nicht f�r Auswahl
            Submit-BTNotification -Content $Content -ActivatedAction $Activated -DismissedAction $Dismissed 
        }else{
            New-BurntToastNotification @notifyOpt -Silent
        }
        #New-BurntToastNotification -UniqueIdentifier $id -Header $headerBT -Silent -Text $title, $message -AppLogo $iconUrl -AppId $appID -Column $Column1, $Column2 -Button $Buttons -ProgressBar $progressAll 
        #Submit-BTNotification -UniqueIdentifier $id -Header $headerBT -Text $title,$message  -ProgressBar $Progress -AppLogo $iconUrl -Button $Button  -Silent -AppId $appID 
        #New-BurntToastNotification -UniqueIdentifier $id -Header $headerBT -Text $title,$message  -ProgressBar $Progress -AppLogo $iconUrl -Button $Button  -Silent -AppId $appID -ExpirationTime $timeout 
        # Pfad zur WAV-Datei
        $wavFilePath =  $sound #"C:\DATEN\iobroker\notification.mp3"
        # Starten des SoundPlayer-Tools
        Start-Process -FilePath "wmplayer.exe" -ArgumentList "/play /close $wavFilePath" -WindowStyle Hidden
        # 2 Sekunden pausieren
        [System.Threading.Thread]::Sleep(2000)
        Stop-Process -Name "wmplayer" -Force
        
    }else{
        Write-Host "Standard-Ton spielen, AppID gesetzt" #-Header $headerBT
        if($onlyUseSubmit){
            Write-Host 'Submit Variante wird genutzt'
            $Text1 = New-BTText -Content $($title)
            $Text2 = New-BTText -Content $($message)
            $action = New-BTAction -Buttons $Buttons -inputs $SelectionBox #$Button, $Button2 # -inputs $SelectionBox #
            # iconUrl und heroImage sind bei Werte setzen nicht m�glich
            #$Binding = New-BTBinding  @BindingOpt #-Children $Text1, $Text2  -Column $Column1, $Column2 #HeroImage funktioniert hier nicht
            if ($Column1 -and $Column2) {
                $Binding = New-BTBinding -Children $Text1, $Text2 -Column $Column1, $Column2
            }
            else {
                $Binding = New-BTBinding -Children $Text1, $Text2
            }
            $Visual = New-BTVisual -BindingGeneric $Binding 
            $Content = New-BTContent -Visual $Visual -Actions $action -Launch 'BodyClick'  # -Duration Long nicht f�r Auswahl
            Submit-BTNotification -Content $Content -ActivatedAction $Activated -DismissedAction $Dismissed 
        }else{
            New-BurntToastNotification @notifyOpt
        }
        #New-BurntToastNotification -UniqueIdentifier $id  -Header $headerBT -Text $title,$message  -ProgressBar $progressAll -AppLogo $iconUrl -Sound Reminder -Button $Buttons  -AppId $appID 
    }
    #$AppId = $appID
    # Hinzuf�gen der App-ID zur Windows-Registrierung
    # New-ItemProperty -Path "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\Repository\Families\$AppId" -Name "PackageFamilyName" -Value "$AppId" -PropertyType String
    #Register-BTApplication -AppId $appID

    # Ereignisverarbeitung
    #$ToastClicked = Wait-BTNotification
    #if ($ToastClicked) {
    #    Write-Host $ToastClicked
    #}
}else{
    $appID = '{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe'
    #$confirm = "YES"
   
    if($soundindex -ge 0){
        Write-Host "MP3 gefunden AppID leer" 
        if($onlyUseSubmit){
            Write-Host 'Submit Variante wird genutzt'
            
            $Text1 = New-BTText -Content $($title)
            $Text2 = New-BTText -Content $($message)
            $action = New-BTAction -Buttons $Buttons -inputs $SelectionBox #$Button, $Button2 # -inputs $SelectionBox #
            # iconUrl und heroImage sind bei Werte setzen nicht m�glich
            #$Binding = New-BTBinding @BindingOpt # -Children $Text1, $Text2  -Column $Column1, $Column2 #HeroImage funktioniert hier nicht
            if ($Column1 -and $Column2) {
                $Binding = New-BTBinding -Children $Text1, $Text2 -Column $Column1, $Column2
            }
            else {
                $Binding = New-BTBinding -Children $Text1, $Text2
            }
            $Visual = New-BTVisual -BindingGeneric $Binding 
            $Content = New-BTContent -Visual $Visual -Actions $action -Launch 'BodyClick'  # -Duration Long nicht f�r Auswahl
            Submit-BTNotification -Content $Content -ActivatedAction $Activated -DismissedAction $Dismissed 
        }else{
            New-BurntToastNotification @notifyOpt -Silent
        }
        #New-BurntToastNotification -UniqueIdentifier $id -Text $title, $message -AppLogo $iconUrl -Silent
        #New-BurntToastNotification -UniqueIdentifier $id -Header $headerBT -Silent -Text $title, $message -AppLogo $iconUrl -AppId $appID -Column $Column1, $Column2 -Button $Buttons -ProgressBar $progressAll -HeroImage $heroImage
        #Submit-BTNotification -UniqueIdentifier $id -Header $headerBT -Text $title,$message  -ProgressBar $Progress -AppLogo $iconUrl -Button $Button  -Silent -ExpirationTime $timeout -AppId $appID -Column $Column1, $Column2 -ActivatedAction { Write-Host 'geklickt ' } -DismissedAction { Write-Host 'Abbruch' } 
        #$notification = New-BurntToastNotification -UniqueIdentifier $id  -Text $title, $message  -ProgressBar $Progress -AppLogo $iconUrl -Button $Button  -Silent -ExpirationTime $timeout -AppId $appID -Column $Column1, $Column2 -ActivatedAction { activate -ButtonContent Content } -DismissedAction { dismissfu -id $Id } 
        
        # Pfad zur WAV-Datei
        $wavFilePath =  $sound #"C:\\DATEN\\ioroker\notification.mp3"
        # Starten des SoundPlayer-Tools
        Start-Process -FilePath "wmplayer.exe" -ArgumentList "/play /close $wavFilePath" -WindowStyle Hidden
        # 2 Sekunden pausieren
        [System.Threading.Thread]::Sleep(2000)
        Stop-Process -Name "wmplayer" -Force
    }else{
        Write-Host "Standard-Ton spielen, AppId leer"
        Write-Host "only" $onlyUseSubmit
        
        #TEST
        #$testText = "10 �C"
        #$modifiedString = Convert-SpecialCharactersToUnicode $testText
        #$escapeString = [System.Management.Automation.LanguagePrimitives]::Escape($testText)
        #$unescapeString = [System.Text.RegularExpressions.Regex]::Unescape($testText)
        #Write-Host $modifiedString
        #$Button = New-BTButton -Content $modifiedString  -Id 'SnoozeTime' -Arguments '10' -ActivationType Background #-snooze
        #$Button2 = New-BTButton -Content "15 $([char]0x00B0)C"  -Id 'Other' -Arguments '15' -ActivationType Background  #-Dismiss  #-Content "Install Now" -Dismiss -Id 'Install' -Id 'Install'
        # Erzeugt ein Button mit zugewiesenem Wert 15
        #$Button2 = New-BTButton -Content "Other"  -Id 'Other' -Arguments '15' -ActivationType Foreground 
        if($onlyUseSubmit){
            Write-Host 'Submit Variante wird genutzt'
            $Text1 = New-BTText -Content $($title)
            $Text2 = New-BTText -Content $($message)
            $action = New-BTAction -Buttons $Buttons -inputs $SelectionBox #$Button, $Button2 # -inputs $SelectionBox #
            # iconUrl und heroImage sind bei Werte setzen nicht m�glich
            #$Binding = New-BTBinding @BindingOpt # -Children $Text1, $Text2  -Column $Column1, $Column2 #HeroImage funktioniert hier nicht
            if ($Column1 -and $Column2) {
                $Binding = New-BTBinding -Children $Text1, $Text2 -Column $Column1, $Column2
            }
            else {
                $Binding = New-BTBinding -Children $Text1, $Text2
            }
            $Visual = New-BTVisual -BindingGeneric $Binding 
            $Content = New-BTContent -Visual $Visual -Actions $action -Launch 'BodyClick'  # -Duration Long nicht f�r Auswahl
            Submit-BTNotification -Content $Content -ActivatedAction $Activated -DismissedAction $Dismissed 
        }else{
            New-BurntToastNotification @notifyOpt
        }
        
        #New-BurntToastNotification -UniqueIdentifier $id -Header $headerBT -Text $title,$message  -ProgressBar $progressAll -AppLogo $iconUrl -Sound Reminder -Button $Buttons -AppId $appID
    }
    #Write-Host $confirm

    # Register-BTApplication -AppId $appID
    

    # Ereignisverarbeitung
    #$ToastClicked = Wait-BTNotification
    #Write-Host $ToastClicked
    #if ($ToastClicked) {
    #    Write-Host $ToastClicked
    #}
}
[System.Threading.Thread]::Sleep($timeToSetValues) # 5000 Sonst kein Event!
#New-BurntToastNotification  -Text 'File copy running' -ProgressBar $Progress -AppLogo "C:\DATEN\iobroker\icon.png" -Button $Button  -Silent

