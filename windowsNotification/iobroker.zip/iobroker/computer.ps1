Param (
    [string]$JsonParameter
)
#Write-Host $JsonParameter

# Bypass der Execution Policy
Set-ExecutionPolicy Bypass -Scope Process -Force


# Monitor Turn off
Add-Type -TypeDefinition @'
    using System;
    using System.Runtime.InteropServices;

    public class Display
    {
        [DllImport("user32.dll")]
        public static extern int SendMessage(int hWnd, int hMsg, int wParam, int lParam);

        public const int HWND_BROADCAST = 0xffff;
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MONITORPOWER = 0xf170;
        public const int MONITOR_OFF = 2;

        public static void TurnOff()
        {
            SendMessage(HWND_BROADCAST, WM_SYSCOMMAND, SC_MONITORPOWER, MONITOR_OFF);
        }
    }
'@


# Set Audio Volume

Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;

[Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioEndpointVolume {
  // f(), g(), ... are unused COM method slots. Define these if you care
  int f(); int g(); int h(); int i();
  int SetMasterVolumeLevelScalar(float fLevel, System.Guid pguidEventContext);
  int j();
  int GetMasterVolumeLevelScalar(out float pfLevel);
  int k(); int l(); int m(); int n();
  int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, System.Guid pguidEventContext);
  int GetMute(out bool pbMute);
}
[Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDevice {
  int Activate(ref System.Guid id, int clsCtx, int activationParams, out IAudioEndpointVolume aev);
}
[Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDeviceEnumerator {
  int f(); // Unused
  int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint);
}
[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumeratorComObject { }

public class Audio {
  static IAudioEndpointVolume Vol() {
    var enumerator = new MMDeviceEnumeratorComObject() as IMMDeviceEnumerator;
    IMMDevice dev = null;
    Marshal.ThrowExceptionForHR(enumerator.GetDefaultAudioEndpoint(/*eRender*/ 0, /*eMultimedia*/ 1, out dev));
    IAudioEndpointVolume epv = null;
    var epvid = typeof(IAudioEndpointVolume).GUID;
    Marshal.ThrowExceptionForHR(dev.Activate(ref epvid, /*CLSCTX_ALL*/ 23, 0, out epv));
    return epv;
  }
  public static float Volume {
    get {float v = -1; Marshal.ThrowExceptionForHR(Vol().GetMasterVolumeLevelScalar(out v)); return v;}
    set {Marshal.ThrowExceptionForHR(Vol().SetMasterVolumeLevelScalar(value, System.Guid.Empty));}
  }
  public static bool Mute {
    get { bool mute; Marshal.ThrowExceptionForHR(Vol().GetMute(out mute)); return mute; }
    set { Marshal.ThrowExceptionForHR(Vol().SetMute(value, System.Guid.Empty)); }
  }
}
'@

<#
[Audio]::Volume #Anzeige Volume
[Audio]::Mute #  Anzeige ist Volume muted
[Audio]::Mute = $true # Ton aus
[Audio]::Mute = $false #Ton an
[Audio]::Volume = 0.75 # Volume setzen

#>


function Send-ToIO {
    param (
        [string]$ioBrokerUrl,
        [string]$stateDP,
        [string]$valueToSend,
        [string]$typeJson
    )

    
    try {
        if($typeJson){
            #$valueToSend = ConvertTo-Json $valueToSend
            #$valueToSend = 'value=$($valueToSend)' 
            $simpleApiUrl = "$ioBrokerUrl/setValueFromBody/$($stateDP)"
            Write-Host 'SimpleApi: ' $simpleApiUrl
           
            Invoke-RestMethod -Uri $simpleApiUrl -Method Post -ContentType "application/json" -Body $valueToSend
        }else{
            $simpleApiUrl = "$ioBrokerUrl/set/$($stateDP)?value=$valueToSend"
            Write-Host 'SimpleApi: ' $simpleApiUrl
            $response = Invoke-RestMethod -Uri $simpleApiUrl -Method Get
        }
        
        Write-Host "Erfolgreich gesendet: $($response)"
    } catch {
        Write-Host "Fehler beim Senden der Anfrage: $($_.Exception.Message)"
    }
}

$receivedData = ConvertFrom-Json $JsonParameter

Write-Host $receivedData
$stateDP = $receivedData.pcDataDP
$ioBrokerUrl = "http://$($receivedData.ipAdressIOB):8087"
$valueToSend = @{}
switch($receivedData.pcCmd){
    "screenOff" {
        [Display]::TurnOff()
        $valueToSend['result'] = 'Bildschirm wurde ausgeschaltet'
    }
    "audioOff" {
        [Audio]::Mute = $true # Ton aus
        $valueToSend['result'] = 'Ton wurde ausgeschaltet'
    }
    "audioOn" {
        [Audio]::Mute = $false # Ton an
        $valueToSend['result'] = 'Ton wurde eingeschaltet'
    }
    "hostname" {
        $valueToSend['result'] = (hostname)
    }
    "pcinfo" {
        $valueToSend['result'] = Get-ComputerInfo
    }
    "os" {
        $valueToSend['result'] = Get-CimInstance Win32_OperatingSystem #| Select-Object Caption, Version, BuildNumber
    }
    "processor" {
        $valueToSend['result'] = Get-CimInstance Win32_Processor #| Select-Object Name, MaxClockSpeed, Manufacturer
    }
    "memory" {
        $valueToSend['result'] = Get-CimInstance Win32_PhysicalMemory #| Select-Object Capacity, Manufacturer, PartNumber
    }
    "disk" {
        $valueToSend['result'] = Get-PhysicalDisk #| Select-Object MediaType, Size, Manufacturer, Model
    }
    "network" {
        $valueToSend['result'] = Get-NetIPAddress #| Select-Object IPAddress, InterfaceAlias
    }
    "software" {
        # Funktioniert Policy nur lokal
        #Set-ExecutionPolicy RemoteSigned
        #Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
        #Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Unrestricted

        #Write-Host (Get-Date).ToString("HH:mm:ss")
        #$job = Start-Job -ScriptBlock {
        #    Get-WmiObject -Class Win32_Product | Select-Object Name, Version
        #}
        #Wait-Job $job
        #$job | Receive-Job -ErrorAction Stop
        #$result = Receive-Job $job
        #Write-Host $result
        #$valueToSend['result'] = $result | ConvertTo-Json
        
    }
    "cpu" {
        $valueToSend['result'] = Get-Counter 
    }
    "service" {
        $valueToSend['result'] = Get-Service
    }
    "history" {
        $valueToSend['result'] = Get-History
    }
    "user" {
        $valueToSend['result'] = Get-LocalUser
    }
    "group"{
        $valueToSend['result'] = Get-LocalGroup
    }
    "location" {
        $valueToSend['result'] = Get-Location #aktuelles Verzeichnis
    }
    "lockpc" {
        $valueToSend['result'] = rundll32.exe user32.dll,LockWorkStation
    }
    "drive" {
        $valueToSend['result'] = Get-PSDrive #Anzeige Laufwerke und Netzwerkzuordnungen
    }
    "devices" {
        $valueToSend['result'] = Get-PnpDevice
    }
    "timezone" {
        $valueToSend['result'] = Get-TimeZone #Anzeige 
    }
    "bright" {
        <#
        Set-ExecutionPolicy RemoteSigned 
        $brightness = 70  # Dieser Wert steht f�r 50 % Helligkeit.
        try {
            # Abrufen der aktuellen Helligkeitseinstellungen
            $currentBrightness = Get-CimInstance -Namespace root/wmi -ClassName WmiMonitorBrightnessMethods

            # �ndern der Helligkeit (in Prozent)
            if ($currentBrightness) {
                $currentBrightness.WmiSetALSBrightness($brightness)
                $valueToSend['result'] = 'Helligkeit gesetzt'
            }else{
                Write-Host 'Nicht vorhanden'
                $valueToSend['result'] = 'Nicht vorhanden'
            }
        } catch {
            Write-Host "Fehler aufgetreten: $_"
        }
        #>
        $valueToSend['result'] = 'Nicht vorhanden'
    }
}


if($receivedData.pcCmd.Contains('audio') -and $receivedData.pcCmd.Contains(' ')){
    $volume = $receivedData.pcCmd -split ' '
    $volume = $volume[1]
    Write-Host $volume
    [Audio]::Volume = $volume
    $valueToSend['result'] = "Ton wurde auf $($volume) gesetzt"
}
# files C:\DATEN\JARVIS funktioniert nicht
# Test-NetConnection funktioniert nicht

if($receivedData.pcCmd.Contains('process') -and $receivedData.pcCmd.Contains(' ')){
    Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
    $processAll = $receivedData.pcCmd -split ' '
    Write-Host $processAll
    $process = $processAll[1] 
    
    Write-Host $process 
    $valueToSend['result'] = Get-Process "$($process)"
}
if($receivedData.pcCmd.Contains('files') -and $receivedData.pcCmd.Contains(' ')){
    Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
    $directory = $receivedData.pcCmd -split ' '
    Write-Host $directory
    $files = $directory[1] 
    
    Write-Host $files
    $valueToSend['result'] = Get-ChildItem "$($files)"
}

if($receivedData.pcCmd.Contains('portcheck') -and $receivedData.pcCmd.Contains(' ')){
    $adressPort = $receivedData.pcCmd -split ' '
    #Write-Host 'Split 1' $adressPort
    $adressPort = $adressPort[1] -split ':'
    #Write-Host 'Split 2' $adressPort
    $ipAdress = $adressPort[0]
    $ipPort   = $adressPort[1]
    Write-Host "$ipAdress $ipPort"
    $valueToSend['result'] = Test-NetConnection $ipAdress -Port $ipPort
}



Write-Host (Get-Date).ToString("HH:mm:ss")
$valueToSend = ConvertTo-Json $valueToSend
Send-ToIO -ioBrokerUrl $ioBrokerUrl -stateDP $stateDP -valueToSend $valueToSend -typeJson $true



<# Abrufen der Computerinformationen
$drive = Get-WmiObject Win32_LogicalDisk | Where-Object { $_.DeviceID -eq 'C:' }
$freeSpaceGB = [math]::Round($drive.FreeSpace / 1GB, 2)

#$cpuCounter = Get-Counter '\Processor(_Total)\% Processor Time'
#$cpuUsage = $cpuCounter.CounterSamples.CookedValue
$cpuUsage = (Get-WmiObject Win32_PerfFormattedData_PerfOS_Processor | Where-Object { $_.Name -eq "_Total" }).PercentProcessorTime
$computerInfo = @{
    #ComputerName = (hostname)
    #OperatingSystem = Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version, BuildNumber
    Processor = Get-CimInstance Win32_Processor | Select-Object Name, MaxClockSpeed, Manufacturer
    Memory = Get-CimInstance Win32_PhysicalMemory | Select-Object Capacity, Manufacturer, PartNumber
    #Disks = Get-PhysicalDisk | Select-Object MediaType, Size, Manufacturer, Model
    #Network = Get-NetIPAddress | Select-Object IPAddress, InterfaceAlias
    #Software = Get-WmiObject -Class Win32_Product | Select-Object Name, Version
    #drive = Get-WmiObject Win32_LogicalDisk | Where-Object { $_.DeviceID -eq 'C:' }
    FreeSpaceGB = $freeSpaceGB
    CpuUsagePercentage = $cpuUsage
}
#>
# Konvertieren des PowerShell-Objekts in JSON
#$jsonData = $computerInfo | ConvertTo-Json

# JSON-Daten anzeigen oder in eine Datei schreiben
#Write-Host $jsonData